<template>
    <div class="peihuo_con">peihuo_con</div>
</template>    

<script>

export default {
    data () {
        return {

        }
    }
}
</script>
<style>

   .peihuo_con{

       height: 320px;
       background-color: brown;
   }

</style>
