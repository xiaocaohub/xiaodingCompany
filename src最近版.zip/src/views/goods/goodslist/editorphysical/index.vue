<template>
  <div class="container">
      编辑实物商品
  </div>
</template>

<script>
export default {
    name: 'editorphysical'
}
</script>

<style>

</style>