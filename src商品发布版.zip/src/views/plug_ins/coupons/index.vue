<template>
  <div class="container">
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: 'coupons',
}
</script>

<style scoped lang="less">

</style>