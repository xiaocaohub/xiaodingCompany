<template>
  <div class="container">
    复制实物商品
  </div>
</template>

<script>
export default {
    name: 'copyphysical'
}
</script>

<style>

</style>