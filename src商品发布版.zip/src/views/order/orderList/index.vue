<template>
  <div class="contsiner">
    <router-view></router-view>
  </div>
</template>

<script>
export default {
    name: 'orderList'
}
</script>

<style>

</style>