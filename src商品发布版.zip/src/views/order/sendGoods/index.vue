<template>
  <div class="contsiner">
    <router-view></router-view>
  </div>
</template>

<script>
export default {
    name: 'sendGoods'
}
</script>

<style>

</style>